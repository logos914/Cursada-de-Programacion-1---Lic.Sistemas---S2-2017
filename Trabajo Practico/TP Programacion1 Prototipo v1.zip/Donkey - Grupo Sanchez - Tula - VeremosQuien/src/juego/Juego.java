package juego;


import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;

public class Juego extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	
	// Variables y métodos propios de cada grupo
	
	Viga suelos[] = new Viga[] {
		
		new Viga(1),
		new Viga(2),
		new Viga(3),
		new Viga(4),
		new Viga(5),
		new Viga(6)
		
		
	};
	
	
			
	
	
	

	
	
	Donkey donkeyKong = new Donkey();
	Personaje jugador = new Personaje(suelos[5]);
	int contador = 0;
	
	
	// ...
	
	Juego()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Donkey - Grupo Apellido1 - Apellido2 -Apellido3 - V0.01", 800, 600);
		
		// Inicializar lo que haga falta para el juego
		// ...
		
		

		// Inicia el juego!
		this.entorno.iniciar();
		
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo
		// ...
		
		for(int i = 0; i < suelos.length; i++) {
			suelos[i].dibujar(entorno);
		}
		
		
		donkeyKong.gorilear(entorno);
		jugador.dibujar(entorno,contador);
		System.out.println(contador);
		contador = contador + 1;
		jugador.saltando(entorno, contador,suelos);
		
		
		

	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		Juego juego = new Juego();
	}
}
