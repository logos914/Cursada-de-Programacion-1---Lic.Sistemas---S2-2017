package juego;

import java.awt.Color;
import juego.Viga;
import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Personaje {

	private String accion;
	private String estado;
	private int posx;
	private int posy;

	private Image mirandoIzquierda;
	private Image mirandoDerecha;
	private String ruta_sonidoCaminar = "rsc/sonidos/walking.wav";

	private Image caminandoIzquierda;
	private Image caminandoDerecha;

	private Image saltandoIzquierda;
	private Image saltandoDerecha;

	private Image subiendo;
	private Image subio;

	private Viga vigaEnLaQueCamino;

	private char ultima;

	private int tiempoSalto;
	private boolean estaSaltando;
	private boolean estaCayendo;

	private int sonando = 1;
	private int sonandoDesde = 0;

	public Personaje(Viga vigasuelo) {

		this.accion = "";
		this.estado = "vivo";
		this.posx = 100;
		this.posy = (int) vigasuelo.dondeEmpiezaElSuelo() - 35;

		this.mirandoIzquierda = Herramientas.cargarImagen("rsc/graficos/marito/mira-izquierda.png");
		this.mirandoDerecha = Herramientas.cargarImagen("rsc/graficos/marito/mira-derecha.png");

		this.caminandoIzquierda = Herramientas.cargarImagen("rsc/graficos/marito/camina-izquierda.gif");
		this.caminandoDerecha = Herramientas.cargarImagen("rsc/graficos/marito/camina-derecha.gif");

		this.saltandoIzquierda = Herramientas.cargarImagen("rsc/graficos/marito/salta-izquierda.png");
		this.saltandoDerecha = Herramientas.cargarImagen("rsc/graficos/marito/salta-derecha.png");

		this.subiendo = Herramientas.cargarImagen("rsc/graficos/marito/subiendo.gif");
		this.subio = Herramientas.cargarImagen("rsc/graficos/marito/subio.gif");

		this.tiempoSalto = 0;
		this.estaSaltando = false;
		this.estaCayendo = false;

	}

	public void hacerSonar(int contador) {
		if (this.sonando == 3 && contador > this.sonandoDesde + 40) {
			Herramientas.play("rsc/sonidos/caminar" + String.valueOf(this.sonando) + ".wav");
			this.sonando = 1;
			this.sonandoDesde = contador;
		}

		else if (this.sonando < 3 && contador > this.sonandoDesde + 40) {

			Herramientas.play("rsc/sonidos/caminar" + String.valueOf(this.sonando) + ".wav");
			this.sonando++;
			this.sonandoDesde = contador;

		}

	}

	public void saltar(Entorno entorno, int contador) {

		if (this.ultima == entorno.TECLA_DERECHA) {

			entorno.dibujarImagen(saltandoDerecha, this.posx, this.posy, 0, 0.090);
			Herramientas.play("rsc/sonidos/jump.wav");
			this.tiempoSalto = contador;
			this.estaSaltando = true;

		} else {

			entorno.dibujarImagen(saltandoIzquierda, this.posx, this.posy, 0, 0.090);
			Herramientas.play("rsc/sonidos/jump.wav");
			this.tiempoSalto = contador;
			this.estaSaltando = true;

		}

	}

	public void saltando(Entorno entorno, int contador, Viga[] suelos) {

		if (estaSaltando && contador - this.tiempoSalto < 30) {

			if (this.ultima == entorno.TECLA_DERECHA) {

				this.posy = this.posy - 1;
				entorno.dibujarImagen(saltandoDerecha, this.posx, this.posy, 0, 0.090);

			} else {

				this.posy = this.posy - 1;
				entorno.dibujarImagen(saltandoIzquierda, this.posx, this.posy, 0, 0.090);

			}

		} else {

			this.estaSaltando = false;

			if (pisando(entorno, suelos) == -1) {

				if (this.ultima == entorno.TECLA_DERECHA) {

					this.posy = this.posy + 1;
					entorno.dibujarImagen(saltandoDerecha, this.posx, this.posy, 0, 0.090);
				}

				else {

					this.posy = this.posy + 1;
					entorno.dibujarImagen(saltandoIzquierda, this.posx, this.posy, 0, 0.090);

				}

			}

		}

	}

	public int pisando(Entorno entorno, Viga[] suelos) {

		for (int i = 0; i < suelos.length; i++) {

			if (this.posy + 20 == (int)suelos[i].dondeEmpiezaElSuelo()) {
				
				if  (this.lateralDerecho() < suelos[i].extremoIzquierdo() || this.lateralIzquierdo() > suelos[i].extremoDerecho() ) {
					this.estaCayendo = true;
					return -1;
				
				}
				else {
					this.estaCayendo = false;
					return i;
				
				}
			}

		}
		this.estaCayendo = true;
		return -1;

	}

	public void dibujar(Entorno entorno, int contador) {

		if (entorno.sePresiono(entorno.TECLA_ESPACIO) && this.tiempoSalto + 60 < contador && this.estaCayendo == false) {

			saltar(entorno, contador);

		}

		
	if (this.estaCayendo == false && this.estaSaltando == false) {
		
		if (entorno.estaPresionada(entorno.TECLA_DERECHA)) {
			
			
			if (this.posx <= 790) {
				this.posx = this.posx + 2;
			}

			entorno.dibujarImagen(caminandoDerecha, this.posx, this.posy, 0, 0.090);
			hacerSonar(contador);
			this.ultima = entorno.TECLA_DERECHA;
			}

		

		else if (entorno.estaPresionada(entorno.TECLA_IZQUIERDA)) {
			
			
			
			if (this.posx >= 10) {
				this.posx = this.posx - 2;
			}

			entorno.dibujarImagen(caminandoIzquierda, this.posx, this.posy, 0, 0.090);
			hacerSonar(contador);
			this.ultima = entorno.TECLA_IZQUIERDA;
			}
	
		else {
		
		if (this.ultima == entorno.TECLA_DERECHA) {
			entorno.dibujarImagen(mirandoDerecha, this.posx, this.posy, 0, 0.090);
		} else {
			entorno.dibujarImagen(mirandoIzquierda, this.posx, this.posy, 0, 0.090);
		}
		
		}
	}
	
	

		
		
		

}	
		
		

	


	
	
	
	
	public int lateralDerecho() {
		return posx + 15;
	}
	
	public int lateralIzquierdo() {
		return posx - 15;
	}
}
