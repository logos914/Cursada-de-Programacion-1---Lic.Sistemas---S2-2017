package juego;
import java.awt.Color;
import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;
import juego.*;


public class Donkey {

public Donkey() {
	
}

public void gorilear(Entorno entorno) {
	
	Image gorila = Herramientas.cargarImagen("rsc/graficos/donkey/gorilear.gif");
	entorno.dibujarImagen(gorila, 50, 30, 0, 0.19);
	
	
	
}


}
