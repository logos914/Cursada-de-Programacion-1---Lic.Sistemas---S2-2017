package juego;

import java.awt.Color;
import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;
import juego.*;


public class Viga {

	
	private int pos;
	private double x;
	private double y;
	private double largo;
	private double alto;
	
	
	public Viga (int pos) {
		
	switch (pos) {
	case 1:
		this.x = 400;
		this.y = 575;
		this.largo = 820;
		this.alto = 25;
		break;
	case 2:
		this.x = 325;
		this.y = 475;
		this.largo = 700;
		this.alto = 25;
		break;
	case 3:
		this.x = 475;
		this.y = 375;
		this.largo = 700;
		this.alto = 25;
		break;
	case 4:
		this.x = 325;
		this.y = 275;
		this.largo = 700;
		this.alto = 25;
		break;
	case 5:
		this.x = 475;
		this.y = 175;
		this.largo = 700;
		this.alto = 25;
		break;
	case 6:
		this.x = 325;
		this.y = 75;
		this.largo = 700;
		this.alto = 25;
		break;
	}
	
		
		
	}
	
	
	public void dibujar(Entorno entorno) {
		
		
				
		entorno.dibujarRectangulo(this.x, this.y, this.largo, this.alto, 0.0, Color.RED );
		
		double paso = this.x - (this.largo / 2) + 10;
		int estado = 90;
		 
		double triangulos = (this.largo / 25) - 4;
		int dibujados = 0;
		
		
		while(dibujados <= triangulos) {
		
		entorno.dibujarTriangulo(paso, this.y, 21, 21, Herramientas.radianes(90), java.awt.Color.BLACK);
		paso += 14;
		entorno.dibujarTriangulo(paso, this.y, 21, 21, Herramientas.radianes(270), java.awt.Color.BLACK);
		paso += 14;
		dibujados +=1;
		
		
		
		}
		
		
	}

	
	public int getPosx() {
		return (int)this.x;
	}
	
	public int getPosy() {
		return (int)this.y;
	}
	
	public int getAncho() {
		return (int)this.largo;
	}
	
	
	
	public double dondeEmpiezaElSuelo() {
		
		return this.y - (this.alto / 2) - 1;		
	}
	
	
	public int extremoIzquierdo() {
		return this.getPosx() - this.getAncho() / 2;
	}
	
	public int extremoDerecho() {
		return this.getPosx() + this.getAncho() / 2;
	}
	
}
